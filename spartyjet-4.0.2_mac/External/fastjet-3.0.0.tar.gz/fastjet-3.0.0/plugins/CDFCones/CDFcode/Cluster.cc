#include "Cluster.hh"

#include <fastjet/internal/base.hh>

FASTJET_BEGIN_NAMESPACE

namespace cdf{

}  // namespace cdf

FASTJET_END_NAMESPACE
